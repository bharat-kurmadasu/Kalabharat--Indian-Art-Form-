import React, { useMemo, useState } from 'react';
import { createRoot } from 'react-dom/client';
import { MapContainer, Marker, Popup, TileLayer, useMap } from 'react-leaflet';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';
import './styles.css';

const file = (name) => `https://commons.wikimedia.org/wiki/Special:FilePath/${encodeURIComponent(name)}`;

const artData = [
  {
    id: 'ajanta', name: 'Ajanta Caves', art: 'Buddhist Murals', state: 'Maharashtra', region: 'West',
    coords: [20.5519, 75.7033], period: '2nd century BCE – c. 480 CE',
    type: 'Painting & Architecture',
    description: 'Ajanta is a group of rock-cut Buddhist cave monuments celebrated for murals, sculptures and narrative scenes connected with Buddhist traditions.',
    context: 'The caves developed in phases and preserve some of the most important surviving examples of ancient Indian mural painting.',
    image: file('Paintings on the Wall of Cave 1, Ajanta Caves, Maharashtra, India 09.jpg'),
    credit: 'Amitabha Gupta, Wikimedia Commons — CC BY 4.0',
    source: 'https://commons.wikimedia.org/wiki/File:Paintings_on_the_Wall_of_Cave_1,_Ajanta_Caves,_Maharashtra,_India_09.jpg'
  },
  {
    id: 'ellora', name: 'Ellora Caves', art: 'Rock-cut Sculpture', state: 'Maharashtra', region: 'West',
    coords: [20.026, 75.178], period: 'c. 600–1000 CE', type: 'Architecture & Sculpture',
    description: 'Ellora brings together Buddhist, Hindu and Jain monuments carved into the rock, including the monumental Kailasa Temple.',
    context: 'Its shared sacred landscape shows the coexistence of multiple religious artistic traditions in the Deccan.',
    image: file('Kailasa Ellora.jpg'), credit: 'Shishirdasika, Wikimedia Commons — CC BY-SA 4.0',
    source: 'https://commons.wikimedia.org/wiki/File:Kailasa_Ellora.jpg'
  },
  {
    id: 'thanjavur', name: 'Thanjavur', art: 'Thanjavur Painting', state: 'Tamil Nadu', region: 'South',
    coords: [10.787, 79.137], period: '16th–19th centuries; court tradition later developed strongly', type: 'Painting',
    description: 'Thanjavur painting is known for rich colours, devotional subjects, gold foil and relief-like ornamentation.',
    context: 'The tradition grew in the cultural environment of South Indian courts and temple communities, especially in Thanjavur.',
    image: file('Thanjavur Painting.jpg'), credit: 'Wikimedia Commons — CC BY-SA 3.0',
    source: 'https://commons.wikimedia.org/wiki/File:Thanjavur_Painting.jpg'
  },
  {
    id: 'khajuraho', name: 'Khajuraho', art: 'Temple Sculpture', state: 'Madhya Pradesh', region: 'Central',
    coords: [24.8318, 79.9199], period: '10th–11th centuries CE', type: 'Sculpture & Architecture',
    description: 'Khajuraho is renowned for richly carved temple surfaces showing deities, dancers, musicians, mythical figures and scenes of everyday life.',
    context: 'The temples were built under the Chandela dynasty and are a major example of medieval Indian temple architecture and sculpture.',
    image: file('Khajuraho sculptures.jpg'), credit: 'Aminesh.aryan, Wikimedia Commons — CC BY-SA 3.0',
    source: 'https://commons.wikimedia.org/wiki/File:Khajuraho_sculptures.jpg'
  },
  {
    id: 'pattachitra', name: 'Puri & Odisha', art: 'Pattachitra', state: 'Odisha', region: 'East',
    coords: [19.8135, 85.8312], period: 'Medieval temple tradition', type: 'Painting',
    description: 'Pattachitra is a traditional cloth-based painting tradition associated strongly with Odisha and Jagannath culture.',
    context: 'Artists use prepared cloth, natural pigments and controlled line work to create narrative and devotional compositions.',
    image: file("Pattachitra from Odisha in Subhas Chandra Bose's parental home, Cuttack, Odisha, India.jpg"),
    credit: 'Wikimedia Commons — image under Creative Commons license',
    source: 'https://commons.wikimedia.org/wiki/File:Pattachitra_from_Odisha_in_Subhas_Chandra_Bose%27s_parental_home,_Cuttack,_Odisha,_India.jpg'
  },
  {
    id: 'madhubani', name: 'Mithila', art: 'Madhubani / Mithila Painting', state: 'Bihar', region: 'East',
    coords: [26.35, 86.07], period: 'Traditional folk art; documented modern form from the 20th century', type: 'Folk Painting',
    description: 'Madhubani painting uses bold outlines, repeated patterns and symbolic images of nature, mythology and social life.',
    context: 'The art comes from the Mithila cultural region and was traditionally practiced in domestic spaces before spreading to paper and other media.',
    image: file('Madhubani painting.jpg'), credit: 'Mohitkiran, Wikimedia Commons — CC BY-SA 3.0',
    source: 'https://commons.wikimedia.org/wiki/File:Madhubani_painting.jpg'
  },
  {
    id: 'kalamkari', name: 'Srikalahasti & Machilipatnam', art: 'Kalamkari', state: 'Andhra Pradesh', region: 'South',
    coords: [13.749, 79.698], period: 'Long textile tradition; major centres in Andhra Pradesh', type: 'Textile Art',
    description: 'Kalamkari is a hand-painted or block-printed textile tradition using detailed drawing, natural-dye processes and narrative motifs.',
    context: 'Two well-known traditions are associated with Srikalahasti and Machilipatnam, with temple and textile histories shaping their visual vocabulary.',
    image: file('Kalamkari.jpg'), credit: 'Ravitheja Kumar Reddy C, Wikimedia Commons — CC BY-SA 4.0',
    source: 'https://commons.wikimedia.org/wiki/File:Kalamkari.jpg'
  },
  {
    id: 'cheriyal', name: 'Cheriyal', art: 'Cheriyal Scroll Painting', state: 'Telangana', region: 'South',
    coords: [17.73, 79.15], period: 'Traditional narrative folk art', type: 'Folk Painting',
    description: 'Cheriyal scrolls use vivid colours and sequential scenes to narrate stories, folklore and community traditions.',
    context: 'The scrolls were historically used by storytelling communities as visual aids during performances and oral narration.',
    image: file('Cheriyal painting - toddy tappers.jpg'), credit: 'Subha murugan, Wikimedia Commons — Creative Commons',
    source: 'https://commons.wikimedia.org/wiki/File:Cheriyal_painting_-_toddy_tappers.jpg'
  },
  {
    id: 'kathakali', name: 'Kerala', art: 'Kathakali', state: 'Kerala', region: 'South',
    coords: [10.52, 76.21], period: '17th century onward', type: 'Performance Art',
    description: 'Kathakali combines dance, theatre, music, elaborate costumes, facial makeup and expressive hand gestures to tell stories.',
    context: 'The performance tradition developed in Kerala and draws on regional theatre and classical Indian performance practices.',
    image: file('KATHAKALI.png'), credit: 'SHARUKH10z, Wikimedia Commons — Creative Commons',
    source: 'https://commons.wikimedia.org/wiki/File:KATHAKALI.png'
  },
  {
    id: 'rajasthani', name: 'Rajasthan', art: 'Rajasthani Miniature Painting', state: 'Rajasthan', region: 'North-West',
    coords: [26.9124, 75.7873], period: '16th–19th centuries', type: 'Miniature Painting',
    description: 'Rajasthani miniature painting developed in several courtly schools and is known for fine line work, vivid colours and narrative scenes.',
    context: 'Themes include court life, portraits, devotional subjects, literature, hunting and landscapes, varying by regional school.',
    image: file('Rajasthani Miniature painting.jpg'), credit: 'Onef9day, Wikimedia Commons — CC BY 3.0',
    source: 'https://commons.wikimedia.org/wiki/File:Rajasthani_Miniature_painting.jpg'
  }
];

const categories = ['All', ...new Set(artData.map((x) => x.type))];

function MarkerIcon() {
  return L.divIcon({
    className: 'custom-marker-wrap',
    html: '<div class="custom-marker">✦</div>',
    iconSize: [34, 34], iconAnchor: [17, 17], popupAnchor: [0, -18]
  });
}

function FlyTo({ selected }) {
  const map = useMap();
  React.useEffect(() => {
    if (selected) map.flyTo(selected.coords, 6, { duration: 1.1 });
  }, [selected, map]);
  return null;
}

function App() {
  const [selected, setSelected] = useState(null);
  const [search, setSearch] = useState('');
  const [category, setCategory] = useState('All');

  const filtered = useMemo(() => artData.filter((x) => {
    const q = search.trim().toLowerCase();
    const matchesSearch = !q || [x.name, x.art, x.state, x.region, x.type].join(' ').toLowerCase().includes(q);
    const matchesCategory = category === 'All' || x.type === category;
    return matchesSearch && matchesCategory;
  }), [search, category]);

  const select = (item) => setSelected(item);

  return (
    <div className="app-shell">
      <header className="topbar">
        <div className="brand" onClick={() => { setSelected(null); setSearch(''); setCategory('All'); }}>
          <div className="brand-mark">क</div>
          <div><span>Kala</span>Bharat <small>INDIAN ART FORMS</small></div>
        </div>
        <nav>
          <a href="#explore">Explore</a>
          <a href="#about">About</a>
        </nav>
      </header>

      <main>
        <section className="hero" id="about">
          <div className="hero-pattern" />
          <div className="hero-copy">
            <p className="eyebrow">INDIAN ART FORMS · CO1</p>
            <h1>Discover the <em>art</em><br />across India.</h1>
            <p className="hero-text">An interactive journey through India's paintings, sculpture, architecture, textiles and performance traditions — one place at a time.</p>
            <a className="hero-btn" href="#explore">Explore the map <span>↓</span></a>
          </div>
          <div className="hero-art" aria-hidden="true">
            <div className="sun" />
            <div className="lotus">✺</div>
            <div className="arch arch-a" /><div className="arch arch-b" />
            <div className="peacock">◉</div>
            <div className="hero-label">भूमि · कला · संस्कृति</div>
          </div>
        </section>

        <section className="explore" id="explore">
          <div className="section-head">
            <div>
              <p className="eyebrow">INTERACTIVE ART MAP</p>
              <h2>Where art <em>lives</em></h2>
            </div>
            <p className="section-note">Click a marker to open the story of an art tradition, its place and historical context.</p>
          </div>

          <div className="controls">
            <div className="search-box"><span>⌕</span><input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search art, state or place..." /></div>
            <div className="chips">{categories.map(c => <button key={c} className={category === c ? 'chip active' : 'chip'} onClick={() => setCategory(c)}>{c}</button>)}</div>
          </div>

          <div className="map-layout">
            <div className="map-card">
              <MapContainer center={[22.6, 79.2]} zoom={5} minZoom={4} maxZoom={10} scrollWheelZoom className="map">
                <TileLayer attribution='&copy; OpenStreetMap contributors &copy; CARTO' url="https://{s}.basemaps.cartocdn.com/light_all/{z}/{x}/{y}{r}.png" />
                <FlyTo selected={selected} />
                {filtered.map(item => <Marker key={item.id} position={item.coords} icon={MarkerIcon()} eventHandlers={{ click: () => select(item) }}>
                  <Popup><strong>{item.name}</strong><br />{item.art}<br /><button className="popup-link" onClick={() => select(item)}>View details →</button></Popup>
                </Marker>)}
              </MapContainer>
              <div className="map-legend"><span className="legend-dot">✦</span> {filtered.length} art locations shown</div>
            </div>

            <aside className="location-list">
              <div className="list-head"><span>{filtered.length} LOCATIONS</span><span>INDIA</span></div>
              {filtered.map(item => <button key={item.id} className={selected?.id === item.id ? 'location-row selected' : 'location-row'} onClick={() => select(item)}>
                <span className="row-icon">✦</span><span><b>{item.name}</b><small>{item.art} · {item.state}</small></span><span className="arrow">→</span>
              </button>)}
            </aside>
          </div>
        </section>

        <section className="spotlight">
          <div className="spotlight-image"><img src={selected?.image || artData[0].image} alt={selected?.art || artData[0].art} /><div className="image-tag">{selected?.type || artData[0].type}</div></div>
          <div className="spotlight-copy">
            <p className="eyebrow">{selected ? selected.state.toUpperCase() : 'FEATURED SITE'}</p>
            <h2>{selected?.art || artData[0].art}</h2>
            <h3>{selected?.name || artData[0].name}</h3>
            <p>{selected?.description || artData[0].description}</p>
            <div className="facts"><div><span>PERIOD</span><b>{selected?.period || artData[0].period}</b></div><div><span>FORM</span><b>{selected?.type || artData[0].type}</b></div></div>
            <p className="context"><b>Historical context</b><br />{selected?.context || artData[0].context}</p>
            {(selected || artData[0]).source && <a className="source-link" href={selected?.source || artData[0].source} target="_blank" rel="noreferrer">View image source & license ↗</a>}
          </div>
        </section>

        <section className="stats">
          <div><strong>10</strong><span>ART LOCATIONS</span></div><div><strong>5</strong><span>REGIONS</span></div><div><strong>7</strong><span>ART CATEGORIES</span></div><div><strong>1000+</strong><span>YEARS OF HERITAGE</span></div>
        </section>
      </main>

      <footer><div><b>KalaBharat</b><span>Interactive Indian Art Map</span></div><p>Created for Indian Art Forms · CO1</p><p>Images sourced from Wikimedia Commons. Please retain individual attribution when reusing.</p></footer>
    </div>
  );
}

createRoot(document.getElementById('root')).render(<App />);

# KalaBharat — Interactive Indian Art Map

A React + Leaflet website for the Indian Art Forms CO1 assignment.

## Run locally

```bash
npm install
npm run dev
```

Open the local URL shown by Vite.

## Build for Vercel

```bash
npm run build
```

Vercel settings for a Vite app:
- Framework Preset: Vite
- Build Command: `npm run build`
- Output Directory: `dist`

No backend or environment variables are required.

## Included
- Interactive India map with clickable art locations
- Search and category filters
- Detailed art, location, period and historical-context panels
- Responsive design for desktop/mobile
- Wikimedia Commons image sources with attribution links
